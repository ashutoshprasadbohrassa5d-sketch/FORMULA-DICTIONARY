"use client";

import { use, useState, useMemo } from "react";
import { formulas, scientists } from "@/app/lib/data";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { explainFormulaConcept, FormulaConceptExplanationOutput } from "@/ai/flows/formula-concept-explanation";
import { generateFormulaPracticeQuestions, FormulaPracticeQuestionGeneratorOutput } from "@/ai/flows/formula-practice-question-generator";
import { Brain, Calculator, Info, PenTool, ArrowLeft, Loader2, Sparkles, LineChart, CheckCircle2, HelpCircle } from "lucide-react";
import Link from "next/link";
import Image from "next/image";
import { PlaceHolderImages } from "@/app/lib/placeholder-images";
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip } from "recharts";

export default function FormulaPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const formula = formulas.find(f => f.id === id);
  const scientist = scientists.find(s => s.id === formula?.scientistId);

  const [explaining, setExplaining] = useState(false);
  const [explanation, setExplanation] = useState<FormulaConceptExplanationOutput | null>(null);

  const [practicing, setPracticing] = useState(false);
  const [practiceData, setPracticeData] = useState<FormulaPracticeQuestionGeneratorOutput | null>(null);

  const [calcInputs, setCalcInputs] = useState<Record<string, number>>({});
  const [calcResult, setCalcResult] = useState<number | null>(null);

  if (!formula) return <div className="p-8">Formula not found.</div>;

  const handleExplain = async () => {
    setExplaining(true);
    try {
      const res = await explainFormulaConcept({ formula: formula.equation });
      setExplanation(res);
    } catch (e) {
      console.error(e);
    } finally {
      setExplaining(false);
    }
  };

  const handlePractice = async () => {
    setPracticing(true);
    try {
      const res = await generateFormulaPracticeQuestions({ 
        formula: formula.equation,
        context: formula.name + ": " + formula.description
      });
      setPracticeData(res);
    } catch (e) {
      console.error(e);
    } finally {
      setPracticing(false);
    }
  };

  const handleCalc = () => {
    setCalcResult(formula.calculate(calcInputs));
  };

  // Generate trend data for the visualization tab
  const chartData = useMemo(() => {
    if (formula.variables.length === 0) return [];
    const mainVar = formula.variables[0].symbol;
    const data = [];
    const baseInputs = { ...calcInputs };
    // Initialize base inputs if empty
    formula.variables.forEach(v => {
      if (baseInputs[v.symbol] === undefined) baseInputs[v.symbol] = 1;
    });

    for (let i = 0; i <= 20; i++) {
      const val = i * (baseInputs[mainVar] || 1) * 0.5;
      const testInputs = { ...baseInputs, [mainVar]: val };
      data.push({
        name: val.toFixed(1),
        result: formula.calculate(testInputs),
      });
    }
    return data;
  }, [formula, calcInputs]);

  const scientistImg = PlaceHolderImages?.find(p => p.id === scientist?.imageId);

  return (
    <div className="p-8 max-w-6xl mx-auto space-y-8 pb-20">
      <Link href="/" className="inline-flex items-center text-sm text-muted-foreground hover:text-primary transition-colors gap-1 mb-4">
        <ArrowLeft className="size-4" /> Back to Dashboard
      </Link>

      <section className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div className="space-y-2">
          <div className="flex items-center gap-3">
            <Badge className="bg-primary/20 text-primary border-none">{formula.field}</Badge>
            <span className="text-muted-foreground">{formula.subField}</span>
          </div>
          <h1 className="font-headline text-5xl font-bold tracking-tight">{formula.name}</h1>
          <div className="math-font text-3xl text-accent py-2">{formula.equation}</div>
        </div>
        
        {scientist && (
          <Card className="max-w-xs border-primary/20 overflow-hidden bg-secondary/20">
            <div className="flex items-center gap-4 p-4">
              <div className="relative size-12 rounded-full overflow-hidden border border-primary/50 shrink-0">
                <Image 
                  src={scientistImg?.imageUrl || `https://picsum.photos/seed/${scientist.id}/100/100`} 
                  alt={scientist.name}
                  fill
                  className="object-cover"
                  data-ai-hint={scientistImg?.imageHint || "portrait"}
                />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-[10px] text-muted-foreground uppercase tracking-widest">Pioneer</p>
                <p className="font-bold text-sm truncate">{scientist.name}</p>
                <p className="text-[10px] text-muted-foreground">{scientist.period}</p>
              </div>
            </div>
          </Card>
        )}
      </section>

      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="bg-secondary/50 p-1 rounded-xl h-auto flex flex-wrap gap-1 border border-border">
          <TabsTrigger value="overview" className="rounded-lg py-2.5 px-6 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
            <Info className="size-4 mr-2" /> Overview
          </TabsTrigger>
          <TabsTrigger value="explanation" className="rounded-lg py-2.5 px-6 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
            <Brain className="size-4 mr-2" /> AI Narrative
          </TabsTrigger>
          <TabsTrigger value="calculator" className="rounded-lg py-2.5 px-6 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
            <Calculator className="size-4 mr-2" /> Live Engine
          </TabsTrigger>
          <TabsTrigger value="viz" className="rounded-lg py-2.5 px-6 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
            <LineChart className="size-4 mr-2" /> Visualizer
          </TabsTrigger>
          <TabsTrigger value="practice" className="rounded-lg py-2.5 px-6 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
            <PenTool className="size-4 mr-2" /> Smart Practice
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="animate-in slide-in-from-bottom-2 duration-300">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <Card className="bg-secondary/10 border-white/5">
              <CardHeader>
                <CardTitle className="font-headline">Variable Analysis</CardTitle>
                <CardDescription>Breakdown of components</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {formula.variables.map((v) => (
                    <div key={v.symbol} className="flex gap-4 p-3 rounded-lg bg-black/20 border border-transparent hover:border-primary/20 transition-all">
                      <div className="size-10 rounded-lg bg-primary/10 flex items-center justify-center font-bold text-primary font-mono shrink-0">
                        {v.symbol}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold">{v.name}</span>
                          <span className="text-[10px] px-2 py-0.5 rounded bg-secondary text-accent font-bold uppercase">{v.unit}</span>
                        </div>
                        <p className="text-sm text-muted-foreground mt-1">{v.description}</p>
                      </div>
                    </div>
                  ))}
                  {formula.variables.length === 0 && <p className="text-muted-foreground italic">No variables defined for this summary formula.</p>}
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-card to-accent/5 border-white/5">
              <CardHeader>
                <CardTitle className="font-headline">Conceptual Basis</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-muted-foreground leading-relaxed text-lg">
                  {formula.description}
                </p>
                <div className="pt-4 border-t border-white/5">
                  <h4 className="font-bold text-sm mb-2 flex items-center gap-2 text-primary uppercase tracking-widest"><Sparkles className="size-3" /> Impact</h4>
                  <p className="text-sm text-muted-foreground italic leading-relaxed">
                    This principle serves as a foundational building block in {formula.subField}, enabling complex predictions and technological advancements across modern {formula.field}.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="explanation" className="animate-in slide-in-from-bottom-2 duration-300">
          <div className="space-y-6">
            {!explanation ? (
              <Card className="border-dashed border-2 border-primary/20 flex flex-col items-center justify-center py-16 text-center space-y-6 bg-secondary/5">
                <div className="size-20 rounded-full bg-primary/10 flex items-center justify-center text-primary shadow-2xl shadow-primary/20">
                  <Brain className="size-10" />
                </div>
                <div className="space-y-2">
                  <CardTitle className="font-headline text-2xl">AI Concept Narrator</CardTitle>
                  <CardDescription className="max-w-md mx-auto text-base">
                    Unlock a deep, contextual narrative explaining the underlying physics and derivations for this specific formula.
                  </CardDescription>
                </div>
                <Button onClick={handleExplain} disabled={explaining} size="lg" className="rounded-full px-8">
                  {explaining ? <><Loader2 className="mr-2 animate-spin" /> Deep Analysis...</> : <><Sparkles className="mr-2" /> Start Narration</>}
                </Button>
              </Card>
            ) : (
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <Card className="lg:col-span-2 border-white/5 bg-secondary/10">
                  <CardHeader>
                    <CardTitle className="font-headline text-3xl">Theoretical Framework</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-8">
                    <div className="prose prose-invert max-w-none text-muted-foreground leading-relaxed text-lg whitespace-pre-wrap">
                      {explanation.principles}
                    </div>
                    <Separator className="bg-white/5" />
                    <div className="space-y-4 bg-primary/5 p-6 rounded-2xl border border-primary/10">
                      <h4 className="font-headline font-bold text-xl text-primary">The "Why" Factor</h4>
                      <p className="text-muted-foreground whitespace-pre-wrap leading-relaxed">
                        {explanation.whyItWorks}
                      </p>
                    </div>
                  </CardContent>
                </Card>
                <Card className="border-white/5 bg-secondary/10">
                  <CardHeader>
                    <CardTitle className="font-headline">Real-World Case Studies</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-4">
                      {explanation.applications.map((app, i) => (
                        <li key={i} className="flex gap-4 text-sm p-4 rounded-xl bg-black/40 border border-white/5">
                          <CheckCircle2 className="size-5 text-accent shrink-0 mt-0.5" />
                          <span className="text-muted-foreground leading-snug">{app}</span>
                        </li>
                      ))}
                    </ul>
                    <Button variant="ghost" className="w-full mt-8 text-xs opacity-50 hover:opacity-100" onClick={() => setExplanation(null)}>Regenerate Insight</Button>
                  </CardContent>
                </Card>
              </div>
            )}
          </div>
        </TabsContent>

        <TabsContent value="calculator" className="animate-in slide-in-from-bottom-2 duration-300">
          <Card className="max-w-2xl mx-auto bg-secondary/10 border-white/5 overflow-hidden">
            <div className="h-2 bg-accent animate-pulse" />
            <CardHeader className="text-center pt-8">
              <CardTitle className="font-headline text-3xl">Calculation Engine</CardTitle>
              <CardDescription>Simulate variables to solve the equation</CardDescription>
            </CardHeader>
            <CardContent className="space-y-8 p-8">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                {formula.variables.map((v) => (
                  <div key={v.symbol} className="space-y-3">
                    <Label htmlFor={v.symbol} className="text-[10px] uppercase font-bold tracking-widest text-muted-foreground block">
                      {v.name} ({v.symbol}) — {v.unit}
                    </Label>
                    <Input 
                      id={v.symbol} 
                      type="number" 
                      placeholder={`Enter value`} 
                      className="bg-black/40 h-12 rounded-xl border-white/10 focus:border-accent"
                      onChange={(e) => setCalcInputs({ ...calcInputs, [v.symbol]: parseFloat(e.target.value) })}
                    />
                  </div>
                ))}
              </div>
              <Button onClick={handleCalc} size="lg" className="w-full bg-accent text-accent-foreground hover:bg-accent/90 py-8 text-xl font-headline font-black rounded-2xl shadow-xl shadow-accent/20">
                Execute Result
              </Button>

              {calcResult !== null && (
                <div className="mt-8 p-8 rounded-3xl bg-gradient-to-br from-primary/20 to-accent/20 border border-white/10 text-center animate-in zoom-in-95 duration-500">
                  <p className="text-[10px] text-primary font-black uppercase tracking-[0.3em] mb-4">Computed Output</p>
                  <div className="text-6xl font-headline font-black text-foreground tabular-nums drop-shadow-2xl">
                    {calcResult.toLocaleString(undefined, { maximumFractionDigits: 6 })}
                  </div>
                  <p className="text-xs text-muted-foreground mt-4 font-medium uppercase">{formula.name.split(' ').pop()} Units</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="viz" className="animate-in slide-in-from-bottom-2 duration-300">
          <Card className="bg-secondary/10 border-white/5">
            <CardHeader>
              <CardTitle className="font-headline">Mathematical Trend Visualization</CardTitle>
              <CardDescription>Showing how the result changes relative to the primary variable</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[400px] w-full mt-4">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={chartData}>
                    <defs>
                      <linearGradient id="colorRes" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.8}/>
                        <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--muted))" />
                    <XAxis 
                      dataKey="name" 
                      stroke="hsl(var(--muted-foreground))" 
                      fontSize={10} 
                      label={{ value: formula.variables[0]?.name || 'Variable', position: 'insideBottom', offset: -5 }}
                    />
                    <YAxis 
                      stroke="hsl(var(--muted-foreground))" 
                      fontSize={10}
                      label={{ value: 'Output', angle: -90, position: 'insideLeft' }}
                    />
                    <Tooltip 
                      contentStyle={{ backgroundColor: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: '12px' }}
                      itemStyle={{ color: 'hsl(var(--primary))' }}
                    />
                    <Area type="monotone" dataKey="result" stroke="hsl(var(--primary))" fillOpacity={1} fill="url(#colorRes)" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
              <p className="text-xs text-muted-foreground text-center mt-6 italic">
                * Trend based on varying {formula.variables[0]?.name || 'the first variable'} while holding others constant.
              </p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="practice" className="animate-in slide-in-from-bottom-2 duration-300">
          <div className="space-y-6">
            {!practiceData ? (
              <Card className="border-dashed border-2 border-accent/20 flex flex-col items-center justify-center py-20 text-center space-y-6 bg-secondary/5">
                <div className="size-20 rounded-full bg-accent/10 flex items-center justify-center text-accent shadow-2xl shadow-accent/20">
                  <PenTool className="size-10" />
                </div>
                <div className="space-y-2">
                  <CardTitle className="font-headline text-2xl">Smart Practice Gen</CardTitle>
                  <CardDescription className="max-w-md mx-auto text-base">
                    Test your understanding with a custom-tailored quiz and problem set generated specifically for {formula.name}.
                  </CardDescription>
                </div>
                <Button onClick={handlePractice} disabled={practicing} variant="outline" size="lg" className="rounded-full px-8 border-accent text-accent hover:bg-accent hover:text-accent-foreground">
                  {practicing ? <><Loader2 className="mr-2 animate-spin" /> Structuring...</> : <><Sparkles className="mr-2" /> Design Problem Set</>}
                </Button>
              </Card>
            ) : (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <Card className="bg-secondary/10 border-white/5">
                  <CardHeader>
                    <CardTitle className="font-headline flex items-center gap-3">
                      <HelpCircle className="size-6 text-primary" /> Application Scenarios
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {practiceData.exampleQuestions.map((q, i) => (
                      <div key={i} className="p-5 rounded-2xl bg-black/40 border border-white/5 relative overflow-hidden group">
                        <div className="absolute top-0 left-0 w-1 h-full bg-primary" />
                        <span className="text-[10px] uppercase font-black text-primary block mb-3 tracking-[0.2em]">Scenario {i+1}</span>
                        <p className="text-sm text-foreground leading-relaxed font-medium">{q}</p>
                      </div>
                    ))}
                  </CardContent>
                </Card>

                <Card className="bg-secondary/10 border-white/5 shadow-2xl shadow-accent/5">
                  <CardHeader>
                    <CardTitle className="font-headline flex items-center gap-3">
                      <Brain className="size-6 text-accent" /> Concept Master Quiz
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-8">
                    {practiceData.quiz.map((q, i) => (
                      <div key={i} className="space-y-4">
                        <p className="font-bold text-sm leading-relaxed">Q{i+1}: {q.question}</p>
                        <div className="grid grid-cols-1 gap-2">
                          {q.options.map((opt, j) => (
                            <Button key={j} variant="outline" className="justify-start h-auto py-4 px-6 text-left whitespace-normal text-xs rounded-xl hover:bg-primary/10 hover:border-primary transition-all">
                              {opt}
                            </Button>
                          ))}
                        </div>
                      </div>
                    ))}
                    <Button variant="ghost" className="w-full text-xs text-muted-foreground hover:text-accent" onClick={() => setPracticeData(null)}>Reset and Refresh Problems</Button>
                  </CardContent>
                </Card>
              </div>
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
