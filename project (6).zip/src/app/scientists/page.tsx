
"use client";

import { scientists } from "@/app/lib/data";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { PlaceHolderImages } from "@/app/lib/placeholder-images";
import Image from "next/image";
import { Badge } from "@/components/ui/badge";
import { History } from "lucide-react";

export default function ScientistsPage() {
  return (
    <div className="p-8 max-w-6xl mx-auto space-y-8">
      <header className="space-y-2">
        <div className="size-12 rounded-xl bg-accent/10 flex items-center justify-center text-accent mb-4">
          <History className="size-6" />
        </div>
        <h1 className="font-headline text-4xl font-bold tracking-tight text-foreground">Scientific Legacy Gallery</h1>
        <p className="text-muted-foreground text-lg max-w-2xl font-medium">
          Celebrating the innovators whose curiosity and genius defined the laws of our universe.
        </p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 pb-24">
        {scientists.map((scientist) => {
          const img = PlaceHolderImages?.find(p => p.id === scientist.imageId);
          return (
            <Card key={scientist.id} className="overflow-hidden border-white/5 bg-secondary/10 group hover:border-primary/50 transition-all rounded-3xl">
              <div className="relative aspect-square w-full">
                <Image 
                  src={img?.imageUrl || `https://picsum.photos/seed/${scientist.id}/600/600`} 
                  alt={scientist.name}
                  fill
                  className="object-cover group-hover:scale-105 transition-transform duration-500 grayscale group-hover:grayscale-0"
                  data-ai-hint={img?.imageHint || scientist.name}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent opacity-80" />
              </div>
              <CardHeader className="p-6">
                <div className="flex items-center justify-between mb-3">
                  <Badge variant="secondary" className="text-[10px] bg-primary/20 text-primary font-black uppercase tracking-widest">{scientist.period}</Badge>
                </div>
                <CardTitle className="font-headline text-2xl font-black uppercase tracking-tight">{scientist.name}</CardTitle>
              </CardHeader>
              <CardContent className="px-6 pb-6">
                <p className="text-muted-foreground text-sm leading-relaxed font-medium">
                  {scientist.contribution}
                </p>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
