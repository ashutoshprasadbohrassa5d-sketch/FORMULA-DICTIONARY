import type {Metadata} from 'next';
import './globals.css';
import { SidebarProvider } from '@/components/ui/sidebar';
import { AxiomSidebar } from '@/components/AxiomSidebar';

export const metadata: Metadata = {
  title: 'Formula Dictionary - Universal Science Explorer',
  description: 'A comprehensive dictionary of scientific formulas, live calculators, and deep insights into the pioneers of science.',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet" />
      </head>
      <body className="font-body antialiased selection:bg-primary selection:text-primary-foreground">
        <SidebarProvider>
          <div className="flex min-h-screen w-full">
            <AxiomSidebar />
            <main className="flex-1 w-full bg-background overflow-x-hidden">
              {children}
            </main>
          </div>
        </SidebarProvider>
      </body>
    </html>
  );
}
