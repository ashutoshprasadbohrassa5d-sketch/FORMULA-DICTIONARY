
"use client";

import { useState } from "react";
import { practiceProblems, fields } from "@/app/lib/data";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BookOpen, Brain, Sparkles, HelpCircle, ChevronRight, Zap, Beaker, Dna, Variable, Settings, Rocket } from "lucide-react";

const iconMap: Record<string, any> = {
  Physics: Zap,
  Chemistry: Beaker,
  Biology: Dna,
  Math: Variable,
  Astronomy: Rocket,
  Engineering: Settings,
};

export default function PracticeCenter() {
  const [selectedField, setSelectedField] = useState("Math");
  const [showHint, setShowHint] = useState<string | null>(null);

  const filteredProblems = practiceProblems.filter(p => p.field === selectedField);

  return (
    <div className="p-8 max-w-6xl mx-auto space-y-12 pb-24">
      <header className="space-y-4">
        <div className="size-16 rounded-2xl bg-accent/20 flex items-center justify-center text-accent shadow-2xl border border-accent/20">
          <Brain className="size-8" />
        </div>
        <h1 className="font-headline text-5xl font-black tracking-tighter uppercase">
          Practice Center
        </h1>
        <p className="text-muted-foreground text-xl max-w-3xl">
          Apply the laws of science and mathematics to real-world word problems. Master the dictionary through active problem solving.
        </p>
      </header>

      <Tabs defaultValue="Math" className="space-y-8" onValueChange={setSelectedField}>
        <TabsList className="bg-secondary/40 p-1 rounded-2xl h-auto flex flex-wrap gap-2 border border-white/5">
          {fields.map((field) => (
            <TabsTrigger 
              key={field.id} 
              value={field.id}
              className="rounded-xl py-3 px-6 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground flex items-center gap-2 transition-all"
            >
              {field.id}
            </TabsTrigger>
          ))}
        </TabsList>

        <TabsContent value={selectedField} className="animate-in fade-in slide-in-from-bottom-4 duration-500">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {filteredProblems.map((problem) => (
              <Card key={problem.id} className="bg-secondary/10 border-white/5 overflow-hidden group hover:border-primary/40 transition-all flex flex-col">
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between mb-4">
                    <Badge variant="outline" className={`
                      ${problem.difficulty === 'Easy' ? 'border-green-500/50 text-green-500 bg-green-500/5' : ''}
                      ${problem.difficulty === 'Medium' ? 'border-yellow-500/50 text-yellow-500 bg-yellow-500/5' : ''}
                      ${problem.difficulty === 'Hard' ? 'border-red-500/50 text-red-500 bg-red-500/5' : ''}
                      px-3 py-1 text-[10px] uppercase font-bold
                    `}>
                      {problem.difficulty}
                    </Badge>
                  </div>
                  <CardTitle className="font-headline text-xl leading-relaxed text-foreground/90">
                    {problem.question}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6 flex-1 flex flex-col justify-end mt-4">
                  {showHint === problem.id && (
                    <div className="p-4 rounded-xl bg-primary/5 border border-primary/20 text-sm italic text-primary animate-in zoom-in-95 duration-300">
                      <Sparkles className="size-4 mb-2" />
                      {problem.hint}
                    </div>
                  )}
                  <div className="flex gap-3">
                    <Button 
                      variant="secondary" 
                      className="flex-1 rounded-xl bg-white/5 hover:bg-white/10"
                      onClick={() => setShowHint(showHint === problem.id ? null : problem.id)}
                    >
                      <HelpCircle className="size-4 mr-2" /> 
                      {showHint === problem.id ? 'Hide Formula' : 'Reveal Hint'}
                    </Button>
                    <Button className="rounded-xl bg-accent text-accent-foreground hover:bg-accent/90">
                      Solve <ChevronRight className="size-4 ml-1" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
            {filteredProblems.length === 0 && (
              <div className="col-span-full py-32 text-center border-2 border-dashed rounded-3xl bg-secondary/5 border-white/10">
                <BookOpen className="size-16 mx-auto mb-6 opacity-10" />
                <p className="text-muted-foreground font-headline text-2xl font-bold">More problems coming soon for {selectedField}.</p>
              </div>
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
