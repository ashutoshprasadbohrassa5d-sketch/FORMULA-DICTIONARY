
"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState, useEffect } from "react";
import { formulas, fields, scientists, type Formula } from "@/app/lib/data";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Zap, Beaker, Dna, Variable, ChevronRight, Sparkles, Settings, History, ArrowRight, BookOpen, Search, Loader2 } from "lucide-react";
import Image from "next/image";
import { PlaceHolderImages } from "@/app/lib/placeholder-images";

const iconMap: Record<string, any> = {
  zap: Zap,
  beaker: Beaker,
  dna: Dna,
  variable: Variable,
  sparkles: Sparkles,
  settings: Settings,
};

export default function FormulaDictionaryDashboard() {
  const router = useRouter();
  const [featuredFormula, setFeaturedFormula] = useState<Formula | null>(null);

  useEffect(() => {
    const random = formulas[Math.floor(Math.random() * formulas.length)];
    setFeaturedFormula(random);
  }, []);

  const handleFeelingLucky = () => {
    const random = formulas[Math.floor(Math.random() * formulas.length)];
    router.push(`/formula/${random.id}`);
  };

  return (
    <div className="p-8 space-y-16 animate-in fade-in duration-1000 pb-24">
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-8 max-w-6xl mx-auto">
        <div className="space-y-4 max-w-2xl">
          <Badge className="bg-primary/20 text-primary border-none font-black tracking-widest px-4 py-1">V2.0 DISCOVERY ENGINE</Badge>
          <h1 className="font-headline text-7xl font-black tracking-tighter bg-clip-text text-transparent bg-gradient-to-r from-primary via-accent to-primary animate-gradient leading-[0.9]">
            Formula <br/> Dictionary
          </h1>
          <p className="text-muted-foreground text-xl leading-relaxed font-medium">
            The definitive scientific compendium. Explore the laws, equations, and pioneers governing our universe through an interactive lens.
          </p>
          <div className="flex gap-4 pt-4">
            <Button size="lg" className="rounded-full px-8 bg-primary text-primary-foreground font-black" asChild>
              <Link href="/directory"><Search className="mr-2 size-5" /> Explore Index</Link>
            </Button>
            <Button size="lg" variant="outline" className="rounded-full px-8 border-accent text-accent hover:bg-accent hover:text-accent-foreground font-black shadow-xl shadow-accent/10" onClick={handleFeelingLucky}>
              <Sparkles className="mr-2 size-5" /> Feeling Lucky
            </Button>
          </div>
        </div>
        
        <div className="hidden lg:block">
          <Card className="bg-secondary/20 border-white/5 backdrop-blur-xl p-8 rounded-[2rem] w-80 text-center space-y-4">
            <div className="size-16 rounded-2xl bg-accent/20 mx-auto flex items-center justify-center text-accent">
              <BookOpen className="size-8" />
            </div>
            <div className="space-y-1">
              <h3 className="font-headline text-3xl font-black">{formulas.length}+</h3>
              <p className="text-xs text-muted-foreground uppercase tracking-widest font-bold">Equations Cataloged</p>
            </div>
          </Card>
        </div>
      </header>

      <section className="space-y-8 max-w-6xl mx-auto">
        <div className="flex items-center justify-between">
          <h2 className="font-headline text-3xl font-black tracking-tight uppercase italic">Scientific Disciplines</h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {fields.map((field) => {
            const fieldImg = PlaceHolderImages?.find(p => p.id === field.imageId);
            const Icon = iconMap[field.icon] || Variable;
            return (
              <Link key={field.id} href={`/field/${field.id}`}>
                <Card className="relative h-80 overflow-hidden group cursor-pointer border-white/5 hover:border-primary/50 transition-all duration-700 shadow-2xl rounded-[2.5rem]">
                  <div className="absolute inset-0 z-0">
                    <Image 
                      src={fieldImg?.imageUrl || `https://picsum.photos/seed/${field.id}/800/600`}
                      alt={field.id}
                      fill
                      className="object-cover group-hover:scale-110 transition-transform duration-1000 opacity-50 grayscale group-hover:grayscale-0"
                      data-ai-hint={fieldImg?.imageHint || "science"}
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-background via-background/60 to-transparent" />
                  </div>
                  <CardContent className="relative z-10 h-full flex flex-col justify-end p-8">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="size-10 rounded-xl bg-primary/20 backdrop-blur-xl flex items-center justify-center text-primary border border-white/10">
                        <Icon className="size-5" />
                      </div>
                      <Badge variant="secondary" className="bg-white/10 text-white border-none text-[10px] font-black uppercase tracking-[0.2em]">{field.subFields.length} specialized Areas</Badge>
                    </div>
                    <h3 className="font-headline font-black text-4xl group-hover:text-primary transition-colors tracking-tighter uppercase">{field.id}</h3>
                    <p className="text-sm text-muted-foreground/80 mt-2 font-medium line-clamp-1">{field.subFields.join(' • ')}</p>
                    <div className="mt-6 flex items-center text-xs font-black text-accent opacity-0 group-hover:opacity-100 transition-all translate-y-4 group-hover:translate-y-0 duration-500 uppercase tracking-widest">
                      Enter Laboratory <ArrowRight className="ml-2 size-4" />
                    </div>
                  </CardContent>
                </Card>
              </Link>
            );
          })}
        </div>
      </section>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
        <Card className="lg:col-span-2 relative overflow-hidden group border-primary/20 bg-secondary/10 rounded-[3rem] min-h-[400px] flex flex-col justify-center">
          {featuredFormula ? (
            <>
              <div className="absolute top-0 right-0 p-12 opacity-5 group-hover:opacity-10 transition-opacity">
                <Sparkles className="size-64 text-accent" />
              </div>
              <CardHeader className="p-10">
                <div className="flex items-center justify-between">
                  <Badge variant="outline" className="text-accent border-accent/50 bg-accent/10 px-4 py-1.5 font-black uppercase tracking-widest text-[10px]">Discovery of the Moment</Badge>
                  <Link href={`/formula/${featuredFormula.id}`} className="text-xs font-black text-primary hover:text-accent flex items-center gap-2 transition-colors uppercase tracking-widest">
                    Deep Dive <ChevronRight className="size-4" />
                  </Link>
                </div>
                <CardTitle className="font-headline text-6xl mt-8 font-black tracking-tighter leading-none">{featuredFormula.name}</CardTitle>
                <div className="py-8">
                  <div className="text-3xl font-serif text-accent math-font bg-black/40 rounded-3xl p-8 inline-block border border-white/5 shadow-inner">
                    {featuredFormula.equation}
                  </div>
                </div>
              </CardHeader>
              <CardContent className="px-10 pb-12 space-y-8">
                <p className="text-xl text-muted-foreground leading-relaxed max-w-2xl font-medium">
                  {featuredFormula.description}
                </p>
                <div className="flex flex-wrap gap-3">
                  {featuredFormula.variables.map((v) => (
                    <Badge key={v.symbol} variant="secondary" className="bg-white/5 hover:bg-white/10 font-mono text-primary font-bold border-white/5 px-4 py-2 rounded-xl text-xs">
                      {v.symbol} → {v.name}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </>
          ) : (
            <div className="flex flex-col items-center justify-center p-20 text-center space-y-4">
              <Loader2 className="size-12 animate-spin text-primary opacity-20" />
              <p className="text-muted-foreground animate-pulse">Selecting featured insight...</p>
            </div>
          )}
        </Card>

        <Card className="bg-secondary/10 border-white/5 rounded-[3rem] flex flex-col">
          <CardHeader className="p-10">
            <CardTitle className="font-headline text-2xl font-black uppercase tracking-tight flex items-center gap-3">
              <History className="size-6 text-primary" /> Scientific Atlas
            </CardTitle>
            <CardDescription className="text-sm font-medium">Historical minds that shaped reality</CardDescription>
          </CardHeader>
          <CardContent className="px-10 pb-10 space-y-6 flex-1">
            {scientists.slice(0, 5).map((scientist) => {
              const img = PlaceHolderImages?.find(p => p.id === scientist.imageId);
              return (
                <div key={scientist.id} className="flex items-center gap-5 group cursor-pointer hover:bg-white/5 p-3 rounded-2xl transition-all border border-transparent hover:border-white/5">
                  <div className="relative size-14 rounded-full overflow-hidden border-2 border-transparent group-hover:border-accent transition-all shrink-0">
                    <Image 
                      src={img?.imageUrl || `https://picsum.photos/seed/${scientist.id}/100/100`} 
                      alt={scientist.name} 
                      fill 
                      className="object-cover"
                      data-ai-hint={img?.imageHint || scientist.name}
                    />
                  </div>
                  <div className="min-w-0">
                    <h4 className="font-black text-base leading-none group-hover:text-primary transition-colors">{scientist.name}</h4>
                    <p className="text-xs text-muted-foreground mt-2 truncate font-medium">{scientist.contribution}</p>
                  </div>
                </div>
              );
            })}
            <Link href="/scientists" className="block text-center text-xs font-black text-primary hover:text-accent pt-10 border-t border-white/5 uppercase tracking-[0.2em]">
              Explore Full Legacy
            </Link>
          </CardContent>
        </Card>
      </div>

      <section className="space-y-12 max-w-6xl mx-auto">
        <div className="flex items-center justify-between border-b border-white/5 pb-8">
          <div>
            <h2 className="font-headline text-4xl font-black uppercase tracking-tighter">The Global Catalog</h2>
            <p className="text-muted-foreground font-medium text-lg mt-2">Instant access to over 100 essential laws and principles</p>
          </div>
          <Button variant="outline" className="rounded-full px-6 font-black uppercase tracking-widest text-[10px]" asChild>
            <Link href="/directory">Full Index Catalog</Link>
          </Button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {formulas.slice(1, 13).map((formula) => (
            <Link key={formula.id} href={`/formula/${formula.id}`}>
              <Card className="hover:scale-[1.02] transition-all hover:bg-secondary/20 bg-secondary/5 border-white/5 group rounded-3xl h-full flex flex-col">
                <CardHeader className="p-8">
                  <div className="flex items-center justify-between mb-6">
                    <Badge className="bg-primary/20 text-primary border-none text-[9px] font-black uppercase tracking-widest">
                      {formula.field}
                    </Badge>
                    <span className="text-[9px] text-muted-foreground font-black uppercase tracking-widest opacity-40">{formula.subField}</span>
                  </div>
                  <CardTitle className="text-2xl font-black group-hover:text-primary transition-colors tracking-tight leading-tight">{formula.name}</CardTitle>
                </CardHeader>
                <CardContent className="px-8 pb-8 mt-auto">
                  <div className="math-font text-accent text-lg bg-black/40 p-4 rounded-2xl truncate border border-white/5 shadow-inner">
                    {formula.equation}
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </section>
    </div>
  );
}
