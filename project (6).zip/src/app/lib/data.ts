
export interface Scientist {
  id: string;
  name: string;
  contribution: string;
  period: string;
  imageId: string;
}

export interface Variable {
  symbol: string;
  name: string;
  unit: string;
  description: string;
}

export interface Formula {
  id: string;
  name: string;
  field: 'Physics' | 'Chemistry' | 'Math' | 'Biology' | 'Astronomy' | 'Engineering';
  subField: string;
  equation: string;
  description: string;
  variables: Variable[];
  scientistId: string;
  calculate: (inputs: Record<string, number>) => number;
}

export interface PracticeProblem {
  id: string;
  field: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  question: string;
  hint: string;
}

export const scientists: Scientist[] = [
  { id: 'einstein', name: 'Albert Einstein', period: '1879–1955', contribution: 'Relativity and Photoelectric effect', imageId: 'einstein' },
  { id: 'newton', name: 'Isaac Newton', period: '1643–1727', contribution: 'Laws of Motion and Universal Gravitation', imageId: 'newton' },
  { id: 'curie', name: 'Marie Curie', period: '1867–1934', contribution: 'Radioactivity and Polonium/Radium', imageId: 'curie' },
  { id: 'euclid', name: 'Euclid', period: 'c. 300 BC', contribution: 'Father of Geometry and Division Lemma', imageId: 'euclid' },
  { id: 'maxwell', name: 'James Clerk Maxwell', period: '1831–1879', contribution: 'Electromagnetic field theory', imageId: 'maxwell' },
  { id: 'boyle', name: 'Robert Boyle', period: '1627–1691', contribution: 'Boyle\'s Law for ideal gases', imageId: 'boyle' },
  { id: 'darwin', name: 'Charles Darwin', period: '1809–1882', contribution: 'Theory of Evolution', imageId: 'darwin' },
  { id: 'mendel', name: 'Gregor Mendel', period: '1822–1884', contribution: 'Laws of Inheritance', imageId: 'mendel' },
  { id: 'pitagoras', name: 'Pythagoras', period: 'c. 570–c. 495 BC', contribution: 'Pythagorean Theorem', imageId: 'pitagoras' },
  { id: 'planck', name: 'Max Planck', period: '1858–1947', contribution: 'Quantum Theory', imageId: 'planck' },
  { id: 'euler', name: 'Leonhard Euler', period: '1707–1783', contribution: 'Analysis and Graph Theory', imageId: 'euler' },
  { id: 'hubble', name: 'Edwin Hubble', period: '1889–1953', contribution: 'Extragalactic Astronomy', imageId: 'hubble' },
  { id: 'hawking', name: 'Stephen Hawking', period: '1942–2018', contribution: 'Black Hole Radiation', imageId: 'hawking' },
  { id: 'tesla', name: 'Nikola Tesla', period: '1856–1943', contribution: 'Alternating Current (AC)', imageId: 'tesla' },
  { id: 'lovelace', name: 'Ada Lovelace', period: '1815–1852', contribution: 'First Computer Algorithm', imageId: 'lovelace' },
  { id: 'faraday', name: 'Michael Faraday', period: '1791–1867', contribution: 'Electromagnetism', imageId: 'faraday' },
  { id: 'kepler', name: 'Johannes Kepler', period: '1571–1630', contribution: 'Laws of Planetary Motion', imageId: 'kepler' },
  { id: 'leibniz', name: 'Gottfried Leibniz', period: '1646–1716', contribution: 'Co-inventor of Calculus', imageId: 'leibniz' },
  { id: 'archimedes', name: 'Archimedes', period: 'c. 287 – c. 212 BC', contribution: 'Buoyancy and Statics', imageId: 'archimedes' },
  { id: 'boltzmann', name: 'Ludwig Boltzmann', period: '1844–1906', contribution: 'Statistical Mechanics', imageId: 'boltzmann' },
  { id: 'bohr', name: 'Niels Bohr', period: '1885–1962', contribution: 'Bohr Model of the Atom', imageId: 'bohr' }
];

export const formulas: Formula[] = [
  // --- MATH / ALGEBRA ---
  {
    id: 'euclid-lemma',
    name: "Euclid's Division Lemma",
    field: 'Math',
    subField: 'Algebra',
    equation: 'a = bq + r',
    description: 'For any two positive integers a and b, there exist unique integers q and r such that a = bq + r, where 0 ≤ r < b.',
    scientistId: 'euclid',
    variables: [
      { symbol: 'b', name: 'Divisor', unit: 'int', description: 'The number being divided by' },
      { symbol: 'q', name: 'Quotient', unit: 'int', description: 'The result of the division' },
      { symbol: 'r', name: 'Remainder', unit: 'int', description: 'The remainder left over' }
    ],
    calculate: (inputs) => (inputs.b || 0) * (inputs.q || 0) + (inputs.r || 0)
  },
  {
    id: 'square-sum-id',
    name: 'Square of a Sum Identity',
    field: 'Math',
    subField: 'Algebra',
    equation: '(a + b)² = a² + 2ab + b²',
    description: 'Algebraic identity for the square of a sum of two terms.',
    scientistId: 'euler',
    variables: [
      { symbol: 'a', name: 'First Term (a)', unit: 'u', description: 'a' },
      { symbol: 'b', name: 'Second Term (b)', unit: 'u', description: 'b' }
    ],
    calculate: (inputs) => Math.pow((inputs.a || 0) + (inputs.b || 0), 2)
  },
  {
    id: 'square-diff-id',
    name: 'Square of a Difference',
    field: 'Math',
    subField: 'Algebra',
    equation: '(a - b)² = a² - 2ab + b²',
    description: 'Algebraic identity for the square of a difference.',
    scientistId: 'euler',
    variables: [
      { symbol: 'a', name: 'First Term (a)', unit: 'u', description: 'a' },
      { symbol: 'b', name: 'Second Term (b)', unit: 'u', description: 'b' }
    ],
    calculate: (inputs) => Math.pow((inputs.a || 0) - (inputs.b || 0), 2)
  },
  {
    id: 'diff-squares-id',
    name: 'Difference of Squares',
    field: 'Math',
    subField: 'Algebra',
    equation: 'a² - b² = (a - b)(a + b)',
    description: 'Algebraic identity showing the difference of two squares.',
    scientistId: 'pitagoras',
    variables: [
      { symbol: 'a', name: 'a', unit: 'u', description: 'First term' },
      { symbol: 'b', name: 'b', unit: 'u', description: 'Second term' }
    ],
    calculate: (inputs) => Math.pow(inputs.a || 0, 2) - Math.pow(inputs.b || 0, 2)
  },

  // --- MATH / TRIGONOMETRY ---
  {
    id: 'trig-reciprocal-sin',
    name: 'Reciprocal Identity (Sine)',
    field: 'Math',
    subField: 'Trigonometry',
    equation: 'sin θ = 1 / cosec θ',
    description: 'The sine of an angle is the reciprocal of its cosecant.',
    scientistId: 'pitagoras',
    variables: [{ symbol: 'c', name: 'cosec θ', unit: 'u', description: 'Value of cosecant' }],
    calculate: (inputs) => 1 / (inputs.c || 1)
  },
  {
    id: 'trig-pythagorean-1',
    name: 'Pythagorean Identity 1',
    field: 'Math',
    subField: 'Trigonometry',
    equation: 'sin²θ + cos²θ = 1',
    description: 'Fundamental identity relating the square of sine and cosine.',
    scientistId: 'pitagoras',
    variables: [{ symbol: 's', name: 'sin θ', unit: 'u', description: 'Sine value' }],
    calculate: (inputs) => 1 - Math.pow(inputs.s || 0, 2) // returns cos^2 theta
  },

  // --- MATH / GEOMETRY & AREA ---
  {
    id: 'circle-area',
    name: 'Area of a Circle',
    field: 'Math',
    subField: 'Geometry',
    equation: 'A = πr²',
    description: 'Surface area within a circular boundary.',
    scientistId: 'archimedes',
    variables: [{ symbol: 'r', name: 'Radius', unit: 'm', description: 'r' }],
    calculate: (inputs) => Math.PI * Math.pow(inputs.r || 0, 2)
  },
  {
    id: 'circle-circum',
    name: 'Circumference of a Circle',
    field: 'Math',
    subField: 'Geometry',
    equation: 'C = 2πr',
    description: 'The distance around a circle.',
    scientistId: 'archimedes',
    variables: [{ symbol: 'r', name: 'Radius', unit: 'm', description: 'r' }],
    calculate: (inputs) => 2 * Math.PI * (inputs.r || 0)
  },
  {
    id: 'area-triangle',
    name: 'Area of a Triangle',
    field: 'Math',
    subField: 'Geometry',
    equation: 'A = 1/2 × b × h',
    description: 'Calculate area using base and height.',
    scientistId: 'euclid',
    variables: [
      { symbol: 'b', name: 'Base', unit: 'm', description: 'Base length' },
      { symbol: 'h', name: 'Height', unit: 'm', description: 'Perpendicular height' }
    ],
    calculate: (inputs) => 0.5 * (inputs.b || 0) * (inputs.h || 0)
  },
  {
    id: 'area-trapezoid',
    name: 'Area of a Trapezoid',
    field: 'Math',
    subField: 'Geometry',
    equation: 'A = 1/2(a + b)h',
    description: 'Area of a four-sided figure with one pair of parallel sides.',
    scientistId: 'euclid',
    variables: [
      { symbol: 'a', name: 'Top Base (a)', unit: 'm', description: 'Side a' },
      { symbol: 'b', name: 'Bottom Base (b)', unit: 'm', description: 'Side b' },
      { symbol: 'h', name: 'Height', unit: 'm', description: 'h' }
    ],
    calculate: (inputs) => 0.5 * ((inputs.a || 0) + (inputs.b || 0)) * (inputs.h || 0)
  },

  // --- MATH / MENSURATION (VOLUME/SA) ---
  {
    id: 'cuboid-volume',
    name: 'Volume of a Cuboid',
    field: 'Math',
    subField: 'Geometry',
    equation: 'V = l × b × h',
    description: 'Total space inside a rectangular prism.',
    scientistId: 'euclid',
    variables: [
      { symbol: 'l', name: 'Length', unit: 'm', description: 'l' },
      { symbol: 'b', name: 'Breadth', unit: 'm', description: 'b' },
      { symbol: 'h', name: 'Height', unit: 'm', description: 'h' }
    ],
    calculate: (inputs) => (inputs.l || 0) * (inputs.b || 0) * (inputs.h || 0)
  },
  {
    id: 'cylinder-volume',
    name: 'Volume of a Cylinder',
    field: 'Math',
    subField: 'Geometry',
    equation: 'V = πr²h',
    description: 'Space occupied by a cylindrical solid.',
    scientistId: 'archimedes',
    variables: [
      { symbol: 'r', name: 'Radius', unit: 'm', description: 'r' },
      { symbol: 'h', name: 'Height', unit: 'm', description: 'h' }
    ],
    calculate: (inputs) => Math.PI * Math.pow(inputs.r || 0, 2) * (inputs.h || 0)
  },
  {
    id: 'cone-volume',
    name: 'Volume of a Cone',
    field: 'Math',
    subField: 'Geometry',
    equation: 'V = 1/3 πr²h',
    description: 'One-third of the volume of a cylinder with same base and height.',
    scientistId: 'archimedes',
    variables: [
      { symbol: 'r', name: 'Radius', unit: 'm', description: 'r' },
      { symbol: 'h', name: 'Height', unit: 'm', description: 'h' }
    ],
    calculate: (inputs) => (1/3) * Math.PI * Math.pow(inputs.r || 0, 2) * (inputs.h || 0)
  },
  {
    id: 'sphere-sa',
    name: 'Surface Area of a Sphere',
    field: 'Math',
    subField: 'Geometry',
    equation: 'SA = 4πr²',
    description: 'Total outer surface of a sphere.',
    scientistId: 'archimedes',
    variables: [{ symbol: 'r', name: 'Radius', unit: 'm', description: 'r' }],
    calculate: (inputs) => 4 * Math.PI * Math.pow(inputs.r || 0, 2)
  },

  // --- PHYSICS / MECHANICS ---
  {
    id: 'phys-velocity',
    name: 'Average Velocity',
    field: 'Physics',
    subField: 'Mechanics',
    equation: 'v = d / t',
    description: 'Rate of change of position with respect to time.',
    scientistId: 'newton',
    variables: [
      { symbol: 'd', name: 'Displacement', unit: 'm', description: 'Change in position' },
      { symbol: 't', name: 'Time', unit: 's', description: 'Duration' }
    ],
    calculate: (inputs) => (inputs.d || 0) / (inputs.t || 1)
  },
  {
    id: 'phys-acceleration',
    name: 'Acceleration',
    field: 'Physics',
    subField: 'Mechanics',
    equation: 'a = (v - u) / t',
    description: 'Rate of change of velocity.',
    scientistId: 'newton',
    variables: [
      { symbol: 'v', name: 'Final Velocity', unit: 'm/s', description: 'v' },
      { symbol: 'u', name: 'Initial Velocity', unit: 'm/s', description: 'u' },
      { symbol: 't', name: 'Time', unit: 's', description: 't' }
    ],
    calculate: (inputs) => ((inputs.v || 0) - (inputs.u || 0)) / (inputs.t || 1)
  },
  {
    id: 'phys-pressure',
    name: 'Pressure Formula',
    field: 'Physics',
    subField: 'Mechanics',
    equation: 'P = F / A',
    description: 'Force applied perpendicular to the surface of an object per unit area.',
    scientistId: 'archimedes',
    variables: [
      { symbol: 'f', name: 'Force', unit: 'N', description: 'Applied force' },
      { symbol: 'a', name: 'Area', unit: 'm²', description: 'Surface area' }
    ],
    calculate: (inputs) => (inputs.f || 0) / (inputs.a || 1)
  },
  {
    id: 'newton-second',
    name: "Newton's Second Law",
    field: 'Physics',
    subField: 'Mechanics',
    equation: 'F = ma',
    description: 'The force acting on an object is equal to the mass of that object times its acceleration.',
    scientistId: 'newton',
    variables: [
      { symbol: 'm', name: 'Mass', unit: 'kg', description: 'Mass of the object' },
      { symbol: 'a', name: 'Acceleration', unit: 'm/s²', description: 'Acceleration' }
    ],
    calculate: (inputs) => (inputs.m || 0) * (inputs.a || 0)
  },

  // --- PHYSICS / THERMODYNAMICS ---
  {
    id: 'thermo-first-law',
    name: 'First Law of Thermodynamics',
    field: 'Physics',
    subField: 'Thermodynamics',
    equation: 'ΔU = Q - W',
    description: 'Change in internal energy equals heat added minus work done.',
    scientistId: 'boltzmann',
    variables: [
      { symbol: 'q', name: 'Heat Input', unit: 'J', description: 'Q' },
      { symbol: 'w', name: 'Work Done', unit: 'J', description: 'W' }
    ],
    calculate: (inputs) => (inputs.q || 0) - (inputs.w || 0)
  },
  {
    id: 'thermo-ideal-gas',
    name: 'Ideal Gas Law',
    field: 'Physics',
    subField: 'Thermodynamics',
    equation: 'PV = nRT',
    description: 'Relationship between pressure, volume, temperature, and amount of gas.',
    scientistId: 'boyle',
    variables: [
      { symbol: 'p', name: 'Pressure', unit: 'Pa', description: 'P' },
      { symbol: 'v', name: 'Volume', unit: 'm³', description: 'V' },
      { symbol: 'n', name: 'Moles', unit: 'mol', description: 'n' },
      { symbol: 't', name: 'Temperature', unit: 'K', description: 'T' }
    ],
    calculate: (inputs) => (inputs.n || 0) * 8.314 * (inputs.t || 0) / (inputs.p || 1) // returns Volume V
  },

  // --- CHEMISTRY / GENERAL ---
  {
    id: 'chem-2n2-rule',
    name: '2n² Rule (Bohr Model)',
    field: 'Chemistry',
    subField: 'General',
    equation: 'Max e⁻ = 2n²',
    description: 'Maximum number of electrons that can be held in an energy shell n.',
    scientistId: 'bohr',
    variables: [{ symbol: 'n', name: 'Shell Number (n)', unit: 'int', description: 'Principal quantum number' }],
    calculate: (inputs) => 2 * Math.pow(inputs.n || 1, 2)
  },
  {
    id: 'chem-moles',
    name: 'Mole Calculation',
    field: 'Chemistry',
    subField: 'General',
    equation: 'n = m / M',
    description: 'Number of moles from mass and molar mass.',
    scientistId: 'boyle',
    variables: [
      { symbol: 'm', name: 'Mass', unit: 'g', description: 'Measured mass' },
      { symbol: 'mm', name: 'Molar Mass', unit: 'g/mol', description: 'Molecular weight' }
    ],
    calculate: (inputs) => (inputs.m || 0) / (inputs.mm || 1)
  },

  // --- PHYSICS / ELECTROMAGNETISM ---
  {
    id: 'electromag-ohm',
    name: "Ohm's Law",
    field: 'Physics',
    subField: 'Electromagnetism',
    equation: 'V = IR',
    description: 'The voltage across a conductor is proportional to the current through it.',
    scientistId: 'tesla',
    variables: [
      { symbol: 'i', name: 'Current', unit: 'A', description: 'I' },
      { symbol: 'r', name: 'Resistance', unit: 'Ω', description: 'R' }
    ],
    calculate: (inputs) => (inputs.i || 0) * (inputs.r || 0)
  },
  {
    id: 'electromag-coulomb',
    name: "Coulomb's Law",
    field: 'Physics',
    subField: 'Electromagnetism',
    equation: 'F = k(q₁q₂/r²)',
    description: 'Electric force between two point charges.',
    scientistId: 'faraday',
    variables: [
      { symbol: 'q1', name: 'Charge 1', unit: 'C', description: 'q₁' },
      { symbol: 'q2', name: 'Charge 2', unit: 'C', description: 'q₂' },
      { symbol: 'r', name: 'Distance', unit: 'm', description: 'r' }
    ],
    calculate: (inputs) => 8.987e9 * ((inputs.q1 || 0) * (inputs.q2 || 0)) / Math.pow(inputs.r || 1, 2)
  },

  // --- ENGINEERING / MECHANICAL ---
  {
    id: 'eng-torque',
    name: 'Torque Formula',
    field: 'Engineering',
    subField: 'Mechanical',
    equation: 'τ = rF sinθ',
    description: 'The rotational equivalent of linear force.',
    scientistId: 'newton',
    variables: [
      { symbol: 'r', name: 'Lever Arm', unit: 'm', description: 'Radius' },
      { symbol: 'f', name: 'Force', unit: 'N', description: 'Applied force' }
    ],
    calculate: (inputs) => (inputs.r || 0) * (inputs.f || 0)
  },
  {
    id: 'eng-bernoulli',
    name: "Bernoulli's Principle",
    field: 'Engineering',
    subField: 'Mechanical',
    equation: 'P + 1/2ρv² + ρgh = const',
    description: 'Relates pressure, velocity, and elevation in fluid flow.',
    scientistId: 'boyle',
    variables: [
      { symbol: 'p', name: 'Pressure', unit: 'Pa', description: 'P' },
      { symbol: 'rho', name: 'Density', unit: 'kg/m³', description: 'ρ' },
      { symbol: 'v', name: 'Velocity', unit: 'm/s', description: 'v' }
    ],
    calculate: (inputs) => (inputs.p || 0) + 0.5 * (inputs.rho || 1) * Math.pow(inputs.v || 0, 2)
  }
];

export const fields = [
  { id: 'Physics', icon: 'zap', imageId: 'field-physics', subFields: ['Mechanics', 'Thermodynamics', 'Relativity', 'Quantum', 'Electromagnetism'] },
  { id: 'Chemistry', icon: 'beaker', imageId: 'field-chemistry', subFields: ['Physical', 'Organic', 'General', 'Kinetics'] },
  { id: 'Biology', icon: 'dna', imageId: 'field-biology', subFields: ['Ecology', 'Genetics', 'Physiology', 'Molecular'] },
  { id: 'Math', icon: 'variable', imageId: 'field-math', subFields: ['Algebra', 'Calculus', 'Trigonometry', 'Statistics', 'Geometry'] },
  { id: 'Astronomy', icon: 'sparkles', imageId: 'field-astronomy', subFields: ['Cosmology', 'Astrophysics', 'Planetary'] },
  { id: 'Engineering', icon: 'settings', imageId: 'field-engineering', subFields: ['Electrical', 'Mechanical', 'Civil'] },
];

export const practiceProblems: PracticeProblem[] = [
  { id: 'p1', field: 'Math', difficulty: 'Easy', question: 'Find the area of a circle with a radius of 7 meters.', hint: 'Use A = πr².' },
  { id: 'p2', field: 'Physics', difficulty: 'Medium', question: 'A force of 500N is applied to an area of 2m². Calculate the pressure.', hint: 'Apply P = F / A.' },
  { id: 'p3', field: 'Chemistry', difficulty: 'Easy', question: 'How many electrons can the 3rd energy shell (n=3) hold?', hint: 'Use the 2n² rule.' },
  { id: 'p4', field: 'Physics', difficulty: 'Easy', question: 'A car travels 100km in 2 hours. What is its average velocity in km/h?', hint: 'Use v = d / t.' },
  { id: 'p5', field: 'Math', difficulty: 'Medium', question: 'Calculate the volume of a cylinder with radius 3m and height 10m.', hint: 'V = πr²h.' }
];
