
"use client";

import { use, useState } from "react";
import { fields, formulas } from "@/app/lib/data";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Zap, Beaker, Dna, Variable, Search, Sparkles, Settings } from "lucide-react";
import Link from "next/link";
import Image from "next/image";
import { PlaceHolderImages } from "@/app/lib/placeholder-images";

const iconMap: Record<string, any> = {
  zap: Zap,
  beaker: Beaker,
  dna: Dna,
  variable: Variable,
  sparkles: Sparkles,
  settings: Settings,
};

export default function FieldPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const field = fields.find(f => f.id === id);
  const [search, setSearch] = useState("");
  const [activeSub, setActiveSub] = useState<string | null>(null);

  if (!field) return <div className="p-8">Field not found.</div>;

  const filteredFormulas = formulas.filter(f => 
    f.field === id && 
    (activeSub ? f.subField === activeSub : true) &&
    (f.name.toLowerCase().includes(search.toLowerCase()) || f.equation.toLowerCase().includes(search.toLowerCase()))
  );

  const Icon = iconMap[field.icon] || Variable;
  const fieldImg = PlaceHolderImages?.find(p => p.id === field.imageId);

  return (
    <div className="p-8 space-y-8 max-w-6xl mx-auto">
      <header className="relative h-64 rounded-3xl overflow-hidden mb-12">
        <Image 
          src={fieldImg?.imageUrl || `https://picsum.photos/seed/${field.id}/1200/400`}
          alt={field.id}
          fill
          className="object-cover opacity-40 grayscale"
          data-ai-hint={fieldImg?.imageHint || "science"}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-background to-transparent" />
        <div className="absolute inset-0 flex flex-col justify-end p-8 space-y-4">
          <div className="flex items-center gap-4">
            <div className="size-16 rounded-2xl bg-primary/20 backdrop-blur-xl flex items-center justify-center text-primary border border-white/10 shadow-2xl">
              <Icon className="size-8" />
            </div>
            <div>
              <h1 className="font-headline text-5xl font-black tracking-tighter uppercase">{field.id}</h1>
              <p className="text-muted-foreground font-medium">Exploring {field.subFields.length} specialized scientific domains</p>
            </div>
          </div>
        </div>
      </header>

      <section className="space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex flex-wrap gap-2">
            <Badge 
              variant={activeSub === null ? "default" : "secondary"} 
              className="cursor-pointer px-6 py-2 rounded-xl text-sm font-bold tracking-tight"
              onClick={() => setActiveSub(null)}
            >
              All Domains
            </Badge>
            {field.subFields.map(sub => (
              <Badge 
                key={sub} 
                variant={activeSub === sub ? "default" : "secondary"} 
                className="cursor-pointer px-6 py-2 rounded-xl text-sm font-bold tracking-tight"
                onClick={() => setActiveSub(sub)}
              >
                {sub}
              </Badge>
            ))}
          </div>
          <div className="relative w-full md:w-80">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
            <Input 
              placeholder={`Search in ${field.id}...`} 
              className="pl-10 h-12 bg-secondary/50 border-border rounded-xl"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 pt-6">
          {filteredFormulas.map((formula) => (
            <Link key={formula.id} href={`/formula/${formula.id}`}>
              <Card className="h-full border-white/5 bg-secondary/10 hover:border-primary/50 hover:bg-secondary/30 transition-all group rounded-2xl">
                <CardHeader>
                  <div className="flex items-center justify-between mb-2">
                    <Badge variant="outline" className="text-[10px] text-muted-foreground border-border uppercase tracking-widest">{formula.subField}</Badge>
                  </div>
                  <CardTitle className="font-headline text-2xl group-hover:text-primary transition-colors font-bold">{formula.name}</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="math-font text-accent text-xl p-4 rounded-xl bg-black/40 border border-white/5 shadow-inner">
                    {formula.equation}
                  </div>
                  <p className="text-sm text-muted-foreground line-clamp-2 leading-relaxed font-medium">
                    {formula.description}
                  </p>
                </CardContent>
              </Card>
            </Link>
          ))}
          {filteredFormulas.length === 0 && (
            <div className="col-span-full py-20 text-center border-2 border-dashed rounded-3xl bg-secondary/5">
              <Sparkles className="size-12 mx-auto mb-4 text-muted-foreground/20" />
              <p className="text-muted-foreground font-headline text-lg">No equations found matching your filters.</p>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
