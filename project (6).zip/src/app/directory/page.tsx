"use client";

import { useState } from "react";
import { formulas } from "@/app/lib/data";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Search, ArrowRight, Sparkles, Loader2, BrainCircuit } from "lucide-react";
import Link from "next/link";
import { discoverFormula } from "@/ai/flows/formula-discovery";

export default function GlobalDirectory() {
  const [search, setSearch] = useState("");
  const [fieldFilter, setFieldFilter] = useState<string | null>(null);
  
  const [aiLoading, setAiLoading] = useState(false);
  const [aiSuggestion, setAiSuggestion] = useState<{ id: string, text: string } | null>(null);

  const filtered = formulas.filter(f => 
    (fieldFilter ? f.field === fieldFilter : true) &&
    (f.name.toLowerCase().includes(search.toLowerCase()) || 
     f.equation.toLowerCase().includes(search.toLowerCase()) ||
     f.field.toLowerCase().includes(search.toLowerCase()))
  );

  const handleAiDiscovery = async () => {
    if (!search.trim()) return;
    setAiLoading(true);
    setAiSuggestion(null);
    try {
      const res = await discoverFormula({ query: search });
      if (res.matchedFormulaId) {
        setAiSuggestion({ id: res.matchedFormulaId, text: res.explanation });
      }
    } catch (e) {
      console.error(e);
    } finally {
      setAiLoading(false);
    }
  };

  return (
    <div className="p-8 max-w-6xl mx-auto space-y-12 pb-24">
      <header className="space-y-4">
        <Badge className="bg-accent/20 text-accent border-none font-black tracking-[0.3em] px-4 py-1">UNIVERSAL INDEX</Badge>
        <h1 className="font-headline text-6xl font-black tracking-tighter italic">Global Directory</h1>
        <p className="text-muted-foreground text-xl font-medium max-w-2xl leading-relaxed">Instant access to the complete library of scientific laws. Use natural language to find formulas.</p>
      </header>

      <div className="space-y-6">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 size-5 text-muted-foreground" />
            <Input 
              placeholder="Search by name, equation, or describe a problem (e.g. 'how to calculate work')..." 
              className="pl-12 h-16 bg-secondary/30 rounded-2xl border-white/10 text-lg focus:ring-accent"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleAiDiscovery()}
            />
          </div>
          <Button 
            onClick={handleAiDiscovery} 
            disabled={aiLoading || !search} 
            size="lg" 
            className="h-16 px-8 rounded-2xl bg-accent text-accent-foreground font-black hover:bg-accent/90"
          >
            {aiLoading ? <Loader2 className="animate-spin" /> : <><BrainCircuit className="mr-2" /> AI Discover</>}
          </Button>
        </div>
        
        <div className="flex flex-wrap gap-2">
          {['Physics', 'Chemistry', 'Biology', 'Math', 'Astronomy', 'Engineering'].map(f => (
            <Badge 
              key={f} 
              variant={fieldFilter === f ? "default" : "outline"}
              className={`cursor-pointer px-6 py-2.5 text-xs font-black uppercase tracking-widest rounded-full transition-all ${fieldFilter === f ? 'bg-primary text-primary-foreground' : 'hover:bg-white/5'}`}
              onClick={() => setFieldFilter(fieldFilter === f ? null : f)}
            >
              {f}
            </Badge>
          ))}
        </div>
      </div>

      {aiSuggestion && (
        <Card className="bg-accent/10 border-accent/30 rounded-3xl p-8 animate-in zoom-in-95 duration-500 overflow-hidden relative">
          <div className="absolute top-0 right-0 p-8 opacity-20"><Sparkles className="size-16 text-accent" /></div>
          <div className="space-y-4 relative z-10">
            <div className="flex items-center gap-2 text-accent font-black text-xs uppercase tracking-widest">
              <Sparkles className="size-4" /> AI Match Found
            </div>
            <p className="text-lg font-medium max-w-3xl leading-relaxed">{aiSuggestion.text}</p>
            <Button asChild className="rounded-full px-8 bg-accent text-accent-foreground font-black">
              <Link href={`/formula/${aiSuggestion.id}`}>View Formula <ArrowRight className="ml-2 size-4" /></Link>
            </Button>
          </div>
        </Card>
      )}

      <div className="grid grid-cols-1 gap-6">
        {filtered.map(f => (
          <Link key={f.id} href={`/formula/${f.id}`}>
            <Card className="hover:bg-secondary/40 transition-all group border-white/5 rounded-[2rem] overflow-hidden">
              <CardContent className="p-8 flex flex-col md:flex-row md:items-center justify-between gap-8">
                <div className="space-y-2 flex-1">
                  <div className="flex items-center gap-3 mb-3">
                    <Badge className="bg-primary/20 text-primary border-none text-[9px] font-black uppercase tracking-[0.2em]">{f.field}</Badge>
                    <span className="text-[10px] text-muted-foreground font-bold uppercase tracking-widest opacity-50">{f.subField}</span>
                  </div>
                  <h3 className="font-headline font-black text-3xl group-hover:text-primary transition-colors tracking-tight italic uppercase">{f.name}</h3>
                  <p className="text-sm text-muted-foreground line-clamp-1 font-medium leading-relaxed">{f.description}</p>
                </div>
                <div className="flex items-center gap-12">
                  <div className="math-font text-2xl text-accent bg-black/40 p-4 rounded-2xl border border-white/5 shadow-inner hidden lg:block">
                    {f.equation}
                  </div>
                  <div className="size-14 rounded-full bg-secondary flex items-center justify-center group-hover:bg-primary group-hover:text-primary-foreground transition-all shadow-xl">
                    <ArrowRight className="size-6" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </Link>
        ))}
        {filtered.length === 0 && (
          <div className="text-center py-32 border-2 border-dashed rounded-[3rem] border-white/5 bg-secondary/5">
            <Search className="size-20 mx-auto mb-6 text-muted-foreground opacity-20" />
            <p className="text-muted-foreground font-headline text-2xl font-black uppercase tracking-widest">Zero Results Found</p>
          </div>
        )}
      </div>
    </div>
  );
}
