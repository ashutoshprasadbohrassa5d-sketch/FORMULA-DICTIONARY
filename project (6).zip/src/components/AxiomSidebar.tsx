
"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { 
  Sidebar, 
  SidebarContent, 
  SidebarGroup, 
  SidebarGroupContent, 
  SidebarGroupLabel, 
  SidebarHeader, 
  SidebarMenu, 
  SidebarMenuButton, 
  SidebarMenuItem 
} from "@/components/ui/sidebar";
import { fields } from "@/app/lib/data";
import { Zap, Beaker, Dna, Variable, LayoutDashboard, Search, History, Sparkles, Settings, Book, Brain } from "lucide-react";

const iconMap: Record<string, any> = {
  zap: Zap,
  beaker: Beaker,
  dna: Dna,
  variable: Variable,
  sparkles: Sparkles,
  settings: Settings,
};

export function AxiomSidebar() {
  const pathname = usePathname();

  return (
    <Sidebar collapsible="icon">
      <SidebarHeader className="border-b border-sidebar-border h-16 flex items-center px-6">
        <Link href="/" className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center shadow-lg shadow-primary/20">
            <Book className="size-5 text-primary-foreground" />
          </div>
          <span className="font-headline font-bold text-lg tracking-tight group-data-[collapsible=icon]:hidden">
            Formula Dictionary
          </span>
        </Link>
      </SidebarHeader>
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel className="font-headline text-xs tracking-wider uppercase text-muted-foreground/50">Core</SidebarGroupLabel>
          <SidebarMenu>
            <SidebarMenuItem>
              <SidebarMenuButton asChild isActive={pathname === "/"}>
                <Link href="/">
                  <LayoutDashboard className="size-4" />
                  <span>Dashboard</span>
                </Link>
              </SidebarMenuButton>
            </SidebarMenuItem>
            <SidebarMenuItem>
              <SidebarMenuButton asChild isActive={pathname === "/directory"}>
                <Link href="/directory">
                  <Search className="size-4" />
                  <span>Global Directory</span>
                </Link>
              </SidebarMenuButton>
            </SidebarMenuItem>
            <SidebarMenuItem>
              <SidebarMenuButton asChild isActive={pathname === "/practice"}>
                <Link href="/practice">
                  <Brain className="size-4" />
                  <span>Practice Center</span>
                </Link>
              </SidebarMenuButton>
            </SidebarMenuItem>
          </SidebarMenu>
        </SidebarGroup>

        <SidebarGroup>
          <SidebarGroupLabel className="font-headline text-xs tracking-wider uppercase text-muted-foreground/50">Disciplines</SidebarGroupLabel>
          <SidebarMenu>
            {fields.map((field) => {
              const Icon = iconMap[field.icon] || Variable;
              return (
                <SidebarMenuItem key={field.id}>
                  <SidebarMenuButton asChild isActive={pathname.startsWith(`/field/${field.id}`)}>
                    <Link href={`/field/${field.id}`}>
                      <Icon className="size-4" />
                      <span>{field.id}</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              );
            })}
          </SidebarMenu>
        </SidebarGroup>

        <SidebarGroup>
          <SidebarGroupLabel className="font-headline text-xs tracking-wider uppercase text-muted-foreground/50">Atlas</SidebarGroupLabel>
          <SidebarMenu>
            <SidebarMenuItem>
              <SidebarMenuButton asChild isActive={pathname === "/scientists"}>
                <Link href="/scientists">
                  <History className="size-4" />
                  <span>The Legacy</span>
                </Link>
              </SidebarMenuButton>
            </SidebarMenuItem>
          </SidebarMenu>
        </SidebarGroup>
      </SidebarContent>
    </Sidebar>
  );
}
