'use server';
/**
 * @fileOverview A Genkit flow for Natural Language Formula Discovery.
 * 
 * - discoverFormula - Finds the best matching formula based on a user's description.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';
import { formulas } from '@/app/lib/data';

const FormulaDiscoveryInputSchema = z.object({
  query: z.string().describe('A natural language description of a problem or concept (e.g., "how fast is something falling?").'),
});

const FormulaDiscoveryOutputSchema = z.object({
  matchedFormulaId: z.string().nullable().describe('The ID of the best matching formula from our library.'),
  explanation: z.string().describe('Why this formula is relevant to the query.'),
  suggestedVariables: z.array(z.string()).describe('Variables the user should look for.'),
});

export async function discoverFormula(input: z.infer<typeof FormulaDiscoveryInputSchema>) {
  return formulaDiscoveryFlow(input);
}

const discoveryPrompt = ai.definePrompt({
  name: 'formulaDiscovery',
  input: { schema: FormulaDiscoveryInputSchema },
  output: { schema: FormulaDiscoveryOutputSchema },
  prompt: `You are the AI Librarian for the Formula Dictionary. 
  The user is describing a problem or concept: "{{{query}}}"
  
  Our available formula IDs are: ${formulas.map(f => f.id).join(', ')}
  
  Based on the user's query, identify the MOST relevant formula ID from the list. If none match well, return null for matchedFormulaId.
  Explain why it matches and what variables they need to measure.`,
});

const formulaDiscoveryFlow = ai.defineFlow(
  {
    name: 'formulaDiscoveryFlow',
    inputSchema: FormulaDiscoveryInputSchema,
    outputSchema: FormulaDiscoveryOutputSchema,
  },
  async (input) => {
    const { output } = await discoveryPrompt(input);
    return output!;
  }
);
