'use server';
/**
 * @fileOverview A Genkit flow for generating practice questions and quizzes based on a given formula.
 *
 * - generateFormulaPracticeQuestions - A function that handles the generation process.
 * - FormulaPracticeQuestionGeneratorInput - The input type for the generateFormulaPracticeQuestions function.
 * - FormulaPracticeQuestionGeneratorOutput - The return type for the generateFormulaPracticeQuestions function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const QuizQuestionSchema = z.object({
  question: z.string().describe('The quiz question.'),
  options: z.array(z.string()).describe('Multiple-choice options for the question.'),
  correctAnswer: z.string().describe('The correct answer among the options.'),
});

const FormulaPracticeQuestionGeneratorInputSchema = z.object({
  formula: z.string().describe('The formula for which to generate questions and quizzes.'),
  context: z.string().optional().describe('Additional context or explanation about the formula, e.g., its subject or purpose.'),
});
export type FormulaPracticeQuestionGeneratorInput = z.infer<typeof FormulaPracticeQuestionGeneratorInputSchema>;

const FormulaPracticeQuestionGeneratorOutputSchema = z.object({
  exampleQuestions: z.array(z.string()).describe('An array of example questions related to the formula.'),
  quiz: z.array(QuizQuestionSchema).describe('A short quiz consisting of multiple-choice questions.'),
});
export type FormulaPracticeQuestionGeneratorOutput = z.infer<typeof FormulaPracticeQuestionGeneratorOutputSchema>;

export async function generateFormulaPracticeQuestions(
  input: FormulaPracticeQuestionGeneratorInput
): Promise<FormulaPracticeQuestionGeneratorOutput> {
  return formulaPracticeQuestionGeneratorFlow(input);
}

const generateFormulaPracticePrompt = ai.definePrompt({
  name: 'generateFormulaPractice',
  input: { schema: FormulaPracticeQuestionGeneratorInputSchema },
  output: { schema: FormulaPracticeQuestionGeneratorOutputSchema },
  prompt: `You are an expert tutor specializing in generating practice questions and quizzes for scientific and mathematical formulas.\nGiven a formula and its context, generate:\n1.  Three distinct example questions that demonstrate the application of the formula.\n2.  A short quiz of two multiple-choice questions related to the formula. Each quiz question should have exactly four options and a single correct answer.\n\nFormula: {{{formula}}}\nContext: {{{context}}}\n\nEnsure the example questions cover different scenarios or aspects of the formula's use.\nThe quiz questions should test understanding and application.`,
});

const formulaPracticeQuestionGeneratorFlow = ai.defineFlow(
  {
    name: 'formulaPracticeQuestionGeneratorFlow',
    inputSchema: FormulaPracticeQuestionGeneratorInputSchema,
    outputSchema: FormulaPracticeQuestionGeneratorOutputSchema,
  },
  async (input) => {
    const { output } = await generateFormulaPracticePrompt(input);
    return output!;
  }
);
