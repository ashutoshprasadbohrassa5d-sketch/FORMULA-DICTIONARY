'use server';
/**
 * @fileOverview A Genkit flow for the AI Concept Narrator to explain scientific/mathematical formulas.
 *
 * - explainFormulaConcept - A function that generates a detailed explanation for a given formula.
 * - FormulaConceptExplanationInput - The input type for the explainFormulaConcept function.
 * - FormulaConceptExplanationOutput - The return type for the explainFormulaConcept function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const FormulaConceptExplanationInputSchema = z.object({
  formula: z.string().describe('The formula for which an explanation is requested (e.g., E=mc^2, F=ma, PV=nRT).'),
});
export type FormulaConceptExplanationInput = z.infer<typeof FormulaConceptExplanationInputSchema>;

const FormulaConceptExplanationOutputSchema = z.object({
  formula: z.string().describe('The formula being explained.'),
  principles: z.string().describe('A detailed explanation of the underlying scientific/mathematical principles.'),
  applications: z.array(z.string()).describe('Examples of practical applications of the formula.'),
  whyItWorks: z.string().describe('A deep dive into the theoretical reasons and derivations behind the formula.'),
});
export type FormulaConceptExplanationOutput = z.infer<typeof FormulaConceptExplanationOutputSchema>;

export async function explainFormulaConcept(input: FormulaConceptExplanationInput): Promise<FormulaConceptExplanationOutput> {
  return formulaConceptExplanationFlow(input);
}

const formulaConceptExplanationPrompt = ai.definePrompt({
  name: 'formulaConceptExplanationPrompt',
  input: { schema: FormulaConceptExplanationInputSchema },
  output: { schema: FormulaConceptExplanationOutputSchema },
  prompt: `You are an AI Concept Narrator, an expert in all fields of science and mathematics, designed to provide deep, contextual explanations of formulas.

Given a formula, generate a clear and concise explanation focusing on its underlying principles, practical applications, and the 'why' behind its operation.

Provide the explanation in a structured JSON format.

Formula: {{{formula}}}`,
});

const formulaConceptExplanationFlow = ai.defineFlow(
  {
    name: 'formulaConceptExplanationFlow',
    inputSchema: FormulaConceptExplanationInputSchema,
    outputSchema: FormulaConceptExplanationOutputSchema,
  },
  async (input) => {
    const { output } = await formulaConceptExplanationPrompt(input);
    if (!output) {
      throw new Error('Failed to generate explanation for the formula.');
    }
    return output;
  }
);
