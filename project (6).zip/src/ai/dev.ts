import { config } from 'dotenv';
config();

import '@/ai/flows/formula-concept-explanation.ts';
import '@/ai/flows/formula-practice-question-generator.ts';
import '@/ai/flows/formula-discovery.ts';
